    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

/**
 *
 * @author Usuario
 */
public class Vista {
      public void mostrarEstado(String estado) {
        System.out.println("Estado: " + estado);
    }

    public void mostrarTemperatura(double temperatura) {
        System.out.println("Temperatura actual: " + temperatura + "°C");
    }

}
