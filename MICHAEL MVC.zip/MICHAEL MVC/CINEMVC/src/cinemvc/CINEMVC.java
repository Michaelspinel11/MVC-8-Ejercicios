/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cinemvc;

import Controlador.Controlador;


public class CINEMVC {

  
    public static void main(String[] args) {
        Controlador controlador = new Controlador(10); 
        controlador.iniciarReserva();
    }
    
}
