/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package intrusosconsensoresmvc;

import Controlador.Controlador;



public class INTRUSOSCONSENSORESMVC {
    public static void main(String[] args) {
         Controlador controlador = new Controlador();
         
         controlador.monitorear(true);
         controlador.ejecutar();

      
    
    
    }
}


    

