/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aireacondicionadomvc;

import Controlador.Controlador;

/**
 *
 * @author Usuario
 */
public class AIREACONDICIONADOMVC {

    
    public static void main(String[] args) {
        Controlador controlador = new Controlador();
        controlador.ejecutarRegistro();
    }
    
}
