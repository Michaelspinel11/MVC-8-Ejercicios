/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package controllucesmvc;

import Controlador.Controlador;

/**
 *
 * @author Usuario
 */
public class CONTROLLUCESMVC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Controlador Controlador = new Controlador();
       Controlador.iniciarSimulacion();
    }
    
}
